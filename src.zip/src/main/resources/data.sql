CREATE TABLE Employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(50) NOT NULL,
    company VARCHAR(255) NOT NULL,
    credit_balance DECIMAL(10, 2) DEFAULT 1000.00
);

INSERT INTO Employees (email,name,company,credit_balance) VALUES ('test@company1.com','test','company1',1000.00);
INSERT INTO Employees (email,name,company,credit_balance) VALUES ('test1@company1.com','test1','company2',1000.00);
INSERT INTO Employees (email,name,company,credit_balance) VALUES ('test2@company1.com','test2','company3',3000.00);
INSERT INTO Employees (email,name,company,credit_balance) VALUES ('test3@company1.com','test3','company4',1200.00);
INSERT INTO Employees (email,name,company,credit_balance) VALUES ('test4@company1.com','test4','company2',2500.00);
