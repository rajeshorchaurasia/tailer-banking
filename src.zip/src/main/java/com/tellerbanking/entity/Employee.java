package com.tellerbanking.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="EMPLOYEES")
public class Employee {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@NotBlank(message = "Email should not be blank")
	@Size(min = 10, max = 225, message = "Invald Email: Email must be 10 to 255 charactors")
	@Column(nullable = false)
	private String email;

	@NotBlank(message = "Name is required")
	@Size(min = 1, max = 50, message = "Invald name: name must be 1 to 50 charactors")
	@Column(nullable = false)
	private String name;

	@NotBlank(message = "Company name should not be blank")
	@Size(min = 1, max = 225, message = "Invald company: company must be 1 to 225 charactors")
	@Column(nullable = false)
	private String company;

	@Column(name = "credit_balance")
	private BigDecimal creditBalance;
	
	//use for junit test run
	public Employee(String name, BigDecimal creditBalance) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.creditBalance = creditBalance;
	}

}
