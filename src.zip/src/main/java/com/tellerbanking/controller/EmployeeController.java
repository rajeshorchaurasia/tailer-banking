package com.tellerbanking.controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tellerbanking.entity.Employee;
import com.tellerbanking.service.EmployeeService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RestController
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@PostMapping
	public ResponseEntity<Map<String, Object>> registerEmployee(@RequestBody Employee employee) {
		log.info("Call registerEmployee for : {}", employee);

		Employee registeredEmployee = employeeService.registerEmployee(employee);
		Map<String, Object> response = new HashMap<>();
		BigDecimal newCredit = registeredEmployee.getCreditBalance();
		response.put("success", true);
		response.put("credit", newCredit);

		log.info("Response registerEmployee for : {}", response);
		return ResponseEntity.ok(response);
	}

	@GetMapping("/balance")
	public ResponseEntity<Map<String, Object>> getBalance(@RequestParam String email) {
		log.info("getBalance for : email:{}", email);

		BigDecimal credit = employeeService.getCreditBalance(email);
		Map<String, Object> response = new HashMap<>();
		response.put("credit", credit);

		log.info("Response getBalance for : {}", response);
		return ResponseEntity.ok(response);
	}

	@GetMapping
	public ResponseEntity<List<Employee>> getAllEmployees() {
		log.info("getAllEmployees");
		List<Employee> employees = employeeService.getAllEmployees();

		log.info("Response getAllEmployees for : {}", employees.size());
		return ResponseEntity.ok(employees);
	}

	@PutMapping
	public ResponseEntity<Map<String, Object>> updateCredit(@RequestBody Employee employee) {
		log.info("updateCredit for : email:{}, creditUpdate:{}", employee.getEmail(), employee.getCreditBalance());
		BigDecimal newCredit = employeeService.updateCredit(employee.getEmail(), employee.getCreditBalance());
		Map<String, Object> response = new HashMap<>();
		response.put("success", true);
		response.put("new_credit", newCredit);

		log.info("Response updateCredit for : {}", response);
		return ResponseEntity.ok(response);
	}

}
