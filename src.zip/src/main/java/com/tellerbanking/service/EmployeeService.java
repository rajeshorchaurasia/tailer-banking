package com.tellerbanking.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tellerbanking.entity.Employee;
import com.tellerbanking.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public Employee registerEmployee(Employee employee) {
		if(employee.getCreditBalance() == null) {
			employee.setCreditBalance(new BigDecimal(1000.00));
		}
		return employeeRepository.save(employee);
	}

	public BigDecimal getCreditBalance(String email) {
		Employee emp = employeeRepository.findByEmail(email);
		return emp.getCreditBalance();
	}

	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}

	public BigDecimal updateCredit(String email, BigDecimal bigDecimal) {
		Employee employee = employeeRepository.findByEmail(email);
		employee.setCreditBalance(bigDecimal);
		employee =  employeeRepository.save(employee);
		return employee.getCreditBalance();
	}

}
