package com.tellerbanking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.tellerbanking")
public class TellerbankingApplication {

	public static void main(String[] args) {
		SpringApplication.run(TellerbankingApplication.class, args);
	}

}
