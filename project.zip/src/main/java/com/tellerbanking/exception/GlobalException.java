package com.tellerbanking.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RestControllerAdvice
public class GlobalException {
	
	@ExceptionHandler(value = MethodArgumentNotValidException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorResponse handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
		log.error("Error: {}",ex.getMessage());
	    return new ErrorResponse(HttpStatus.BAD_REQUEST.value(), ex.getFieldError().getDefaultMessage());
	}
	
	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<Object>  handlerCustomException (Exception ex) {
		log.error("Error: globle exception {}",ex.getMessage());
		Map<String, Object> body = new HashMap<>();
		body.put("status code: ", HttpStatus.NOT_FOUND.value());
		body.put("message : ", ex.getMessage());
		return new ResponseEntity<> (body, HttpStatus.NOT_FOUND);
	}
}
