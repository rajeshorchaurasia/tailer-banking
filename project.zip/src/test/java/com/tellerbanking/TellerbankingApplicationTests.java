package com.tellerbanking;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.tellerbanking.controller.EmployeeController;
import com.tellerbanking.entity.Employee;
import com.tellerbanking.service.EmployeeService;

@SpringBootTest
@AutoConfigureMockMvc
public class TellerbankingApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private EmployeeService employeeService;

    @InjectMocks
    private EmployeeController employeeController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(employeeController).build();
    }

    @Test
    public void testRegisterEmployee() throws Exception {
        Employee registeredEmployee = new Employee("john.doe@example.com", new BigDecimal("100.00"));
        when(employeeService.registerEmployee(any(Employee.class))).thenReturn(registeredEmployee);

        mockMvc.perform(post("/employees")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"john.doe@example.com\", \"creditBalance\":0}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.credit").value(100.00));

        verify(employeeService, times(1)).registerEmployee(any(Employee.class));
    }

    @Test
    public void testGetBalance() throws Exception {
        String email = "john.doe@example.com";
        BigDecimal credit = new BigDecimal("100.00");
        when(employeeService.getCreditBalance(email)).thenReturn(credit);

        mockMvc.perform(get("/employees/balance")
                .param("email", email))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.credit").value(100.00));

        verify(employeeService, times(1)).getCreditBalance(email);
    }

    @Test
    public void testGetAllEmployees() throws Exception {
        List<Employee> employees = Arrays.asList(
                new Employee("john.doe@example.com", new BigDecimal("100.00")),
                new Employee("jane.doe@example.com", new BigDecimal("200.00"))
        );
        when(employeeService.getAllEmployees()).thenReturn(employees);

        mockMvc.perform(get("/employees"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2));

        verify(employeeService, times(1)).getAllEmployees();
    }

    @Test
    public void testUpdateCredit() throws Exception {
        when(employeeService.updateCredit(any(String.class), any(BigDecimal.class))).thenReturn(new BigDecimal("150.00"));

        mockMvc.perform(put("/employees")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"john.doe@example.com\", \"creditBalance\":150}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.new_credit").value(150.00));

        verify(employeeService, times(1)).updateCredit(any(String.class), any(BigDecimal.class));
    }
}
